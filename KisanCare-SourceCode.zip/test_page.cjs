const { spawn } = require('child_process');
const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const proc = spawn(edgePath, [
  '--headless',
  '--disable-gpu',
  '--remote-debugging-port=9222',
  'https://klusujith.github.io/KisanCare/'
]);

setTimeout(async () => {
  try {
    const listRes = await fetch('http://127.0.0.1:9222/json/list');
    const tabs = await listRes.json();
    console.log('Open tabs:', tabs.length);
    const target = tabs.find(t => t.url.includes('klusujith.github.io'));
    if (!target) {
      console.log('Target tab not found:', tabs);
      proc.kill();
      return;
    }
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    ws.onopen = () => {
      ws.send(JSON.stringify({ id: 1, method: 'Console.enable' }));
      ws.send(JSON.stringify({ id: 2, method: 'Runtime.enable' }));
      ws.send(JSON.stringify({ id: 3, method: 'Page.enable' }));
    };
    ws.onmessage = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.method === 'Runtime.consoleAPICalled') {
        console.log('[BROWSER CONSOLE]', data.params.type, data.params.args.map(a => a.value || a.description).join(' '));
      } else if (data.method === 'Runtime.exceptionThrown') {
        console.error('[BROWSER RUNTIME ERROR]', data.params.exceptionDetails.text, data.params.exceptionDetails.exception?.description);
      }
      if (data.id === 4) {
        console.log('[ROOT HTML RESULT]:', data.result?.result?.value);
        ws.close();
        proc.kill();
        process.exit(0);
      }
    };
    setTimeout(() => {
      ws.send(JSON.stringify({
        id: 4,
        method: 'Runtime.evaluate',
        params: { expression: 'document.getElementById("root") ? document.getElementById("root").innerHTML.substring(0, 300) : "NO ROOT"' }
      }));
    }, 4000);
  } catch(e) {
    console.error('CDP error:', e);
    proc.kill();
  }
}, 2000);
